-- BigSky AI: Stage 2 schema. Every row belongs to one user and is protected by RLS.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  timezone text not null default 'Asia/Manila',
  monitor_interval_minutes int not null default 30 check (monitor_interval_minutes between 5 and 1440),
  daily_summary_hour int not null default 18 check (daily_summary_hour between 0 and 23),
  notify_email boolean not null default false,
  notify_push boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  d2l_org_unit_id text,
  name text not null,
  code text,
  instructor text,
  color text default '#4f46e5',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (user_id, d2l_org_unit_id)
);

create table public.assignments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  d2l_id text,
  title text not null,
  instructions text,
  kind text not null default 'assignment' check (kind in ('assignment','quiz','exam')),
  published_at timestamptz,
  due_at timestamptz,
  status text not null default 'not_started' check (status in ('not_started','in_progress','completed','submitted')),
  submission_verified boolean not null default false,
  priority text not null default 'normal' check (priority in ('low','normal','high')),
  notes text,
  ai_draft text,
  content_hash text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, d2l_id),
  -- "submitted" is only allowed when the portal confirmed it
  constraint submitted_must_be_verified check (status <> 'submitted' or submission_verified)
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid not null references public.courses(id) on delete cascade,
  d2l_id text, title text not null, body text,
  posted_at timestamptz, content_hash text,
  created_at timestamptz not null default now(),
  unique (user_id, d2l_id)
);

-- Files from BigSky (lesson PDFs etc.). The file itself lives in the private "files" storage bucket.
create table public.materials (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid references public.courses(id) on delete cascade,
  assignment_id uuid references public.assignments(id) on delete set null,
  d2l_id text, title text not null, mime_type text,
  storage_path text, content_hash text, posted_at timestamptz,
  source text not null default 'bigsky' check (source in ('bigsky','upload')),
  created_at timestamptz not null default now(),
  unique (user_id, d2l_id)
);

create table public.generated_work (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  assignment_id uuid references public.assignments(id) on delete set null,
  course_id uuid references public.courses(id) on delete set null,
  title text not null, format text, content text, review_flags jsonb default '[]',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null, title text not null, body text, link text,
  dedupe_key text, read_at timestamptz, sent_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, dedupe_key)  -- prevents duplicate alerts
);

create table public.monitor_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid references public.courses(id) on delete set null,
  entity text not null, entity_id uuid,
  change text not null check (change in ('created','updated','deadline_changed','removed')),
  before jsonb, after jsonb,
  detected_at timestamptz not null default now()
);

create table public.ai_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid references public.courses(id) on delete set null,
  title text, created_at timestamptz not null default now()
);

create table public.ai_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid not null references public.ai_conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null, created_at timestamptz not null default now()
);

create index on public.assignments (user_id, due_at);
create index on public.announcements (user_id, posted_at desc);
create index on public.materials (user_id, course_id);
create index on public.monitor_events (user_id, detected_at desc);
create index on public.notifications (user_id, created_at desc);

-- keep updated_at fresh
create function public.touch() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
create trigger t_assign before update on public.assignments for each row execute function public.touch();
create trigger t_gen before update on public.generated_work for each row execute function public.touch();

-- profile row on signup
create function public.new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin insert into public.profiles (id, display_name) values (new.id, split_part(new.email,'@',1)); return new; end $$;
create trigger on_signup after insert on auth.users for each row execute function public.new_user();

-- Row Level Security: a user can only see and change their own rows
alter table public.profiles enable row level security;
create policy own_profile on public.profiles for all to authenticated
  using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

do $$
declare t text;
begin
  foreach t in array array['courses','assignments','announcements','materials','generated_work',
    'notifications','monitor_events','ai_conversations','ai_messages'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy own_rows on public.%I for all to authenticated
      using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id)', t);
  end loop;
end $$;

-- Private file storage: each user may only touch files under a folder named with their own user id
insert into storage.buckets (id, name, public) values ('files','files',false) on conflict do nothing;
create policy own_files on storage.objects for all to authenticated
  using (bucket_id = 'files' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'files' and (storage.foldername(name))[1] = (select auth.uid())::text);
