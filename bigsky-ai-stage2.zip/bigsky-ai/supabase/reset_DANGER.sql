-- DANGER: deletes ALL BigSky AI tables and their data. Only use this if the first run failed halfway,
-- or you want to start over while the app is still empty. Do not run it once you have real data.
drop trigger if exists on_signup on auth.users;
drop policy if exists own_files on storage.objects;
drop table if exists public.ai_messages, public.ai_conversations, public.monitor_events,
  public.notifications, public.generated_work, public.materials, public.announcements,
  public.assignments, public.courses, public.profiles cascade;
drop function if exists public.new_user();
drop function if exists public.touch();
