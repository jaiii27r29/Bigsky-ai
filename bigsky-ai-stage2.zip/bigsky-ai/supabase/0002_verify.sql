-- READ-ONLY checks. Safe to run any time. Run each block and compare with the expected result in SETUP-SQL.md.

-- Check 1: should list 10 tables
select table_name from information_schema.tables
where table_schema = 'public' order by table_name;

-- Check 2: every row should show rls_on = true
select tablename, rowsecurity as rls_on from pg_tables
where schemaname = 'public' order by tablename;

-- Check 3: should list 10 policies for public tables (one per table) plus own_files
select schemaname, tablename, policyname from pg_policies
where schemaname in ('public','storage') and policyname in ('own_profile','own_rows','own_files')
order by schemaname, tablename;

-- Check 4: should return one row, public = false
select id, public from storage.buckets where id = 'files';

-- Check 5: should return one row named on_signup
select tgname from pg_trigger where tgname = 'on_signup';
