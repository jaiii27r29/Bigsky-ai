# Setting up the database (SQL Editor), step by step

Works in Safari on an iPad. Takes about 5 minutes. You only do this once.

## Before you start
- You need a Supabase project (free plan is fine). If you do not have one: supabase.com > Sign in > New project. Pick a name, set a database password (save it in a password manager, you will not need it for this app), choose a region close to the Philippines (Southeast Asia / Singapore), and wait about 2 minutes until the project finishes setting up.

## Step 1: Open the SQL Editor
1. Open your project in Supabase.
2. In the left menu (tap the menu icon at the top left if you are on a small screen), tap **SQL Editor**.
3. Tap **New query** (or the + button). You now have an empty box.

## Step 2: Paste and run the main script
1. Open `supabase/migrations/0001_init.sql` from this folder. On iPad, tap the file in Files > Quick Look > select all > Copy. (Or open it in any text editor.)
2. Go back to the SQL Editor, tap inside the empty box, and Paste. Paste the WHOLE file, from `-- BigSky AI: Stage 2 schema` to the last line.
3. Tap **Run** (bottom right; on a keyboard, Ctrl/Cmd + Enter).
4. Expected result: **Success. No rows returned.** That is the correct result, because the script only creates things.
5. If Supabase shows a warning about "destructive operations" or asks you to confirm, read it. This script only creates new things, so it should not. If it does show a warning, stop and send me a screenshot.

## Step 3: Verify it worked
1. Tap **New query** again.
2. Open `supabase/0002_verify.sql`, copy ONE check at a time (each begins with a `-- Check` line), paste, and Run.
3. Compare with this table:

| Check | What you should see |
|---|---|
| 1 | 10 tables: ai_conversations, ai_messages, announcements, assignments, courses, generated_work, materials, monitor_events, notifications, profiles |
| 2 | Every table shows `rls_on` = true |
| 3 | 11 rows: 10 policies on public tables (profiles uses own_profile, the other 9 use own_rows) plus own_files on storage objects |
| 4 | One row, `id` = files, `public` = false |
| 5 | One row, `tgname` = on_signup |

You can also tap **Table Editor** in the left menu and you should see the 10 tables listed.

## Step 4: Check the storage bucket
Left menu > **Storage**. You should see a bucket named **files** with a lock icon (private). Do not make it public.

## Step 5: Turn on the sign-in method and lock the door
1. Left menu > **Authentication** > **Sign In / Providers**. Make sure **Email** is enabled. (Magic link sign-in is on by default.)
2. Left menu > **Authentication** > **URL Configuration**. Set **Site URL** to your deployed app address (for example https://your-app.vercel.app). Under Redirect URLs add: `https://your-app.vercel.app/auth/callback`
3. Sign in to the app once with your email, tap the link in the email, and confirm the starter page shows your email.
4. THEN go back to Sign In / Providers and turn **off** "Allow new users to sign up". This means nobody else can ever create an account. You can still sign in because your account already exists.

## Step 6: Copy your keys for the app
Left menu > **Project Settings** (gear) > **API** (or **API Keys**).
- **Project URL** goes in `NEXT_PUBLIC_SUPABASE_URL`.
- The **anon / publishable** key goes in `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
- Do NOT use the **service_role / secret** key yet, and never paste it into anything that starts with NEXT_PUBLIC_.

## If something goes wrong
| What you see | What it means | What to do |
|---|---|---|
| `relation "profiles" already exists` (or any "already exists") | The script ran before, fully or partly | Run Check 1. If you have fewer than 10 tables, run `supabase/reset_DANGER.sql` once (it wipes the app's tables, fine while empty), then run 0001_init.sql again. If you already have 10 tables, you are done. |
| `permission denied` or `must be owner` on storage lines | Rare. The storage part was blocked | Send me the exact error text. Everything above the storage lines is fine. |
| `syntax error at or near ...` | Part of the file was missed when copying | Clear the editor, copy the whole file again, paste, Run. |
| Check 1 shows fewer than 10 tables | Script did not finish | Same as the first row: reset, then rerun. |
| Check 2 shows `false` anywhere | RLS is off for that table, which is unsafe | Send me the table name. Do not enter real data yet. |

## Safety notes
- reset_DANGER.sql deletes data. Never run it once you have real assignments or files saved.
- Nothing in these scripts contains your BigSky password, and the app never asks for it.
