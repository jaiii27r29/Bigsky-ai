export const metadata = { title: 'BigSky AI' }
export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body style={{ fontFamily: '-apple-system, system-ui, sans-serif', margin: 0, padding: 24, maxWidth: 560 }}>{children}</body></html>)
}
