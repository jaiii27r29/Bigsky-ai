'use client'
import { useState } from 'react'
import { supabaseBrowser } from '@/lib/supabase/client'

export default function Login() {
  const [email, setEmail] = useState('')
  const [msg, setMsg] = useState('')
  async function send(e: React.FormEvent) {
    e.preventDefault()
    const { error } = await supabaseBrowser().auth.signInWithOtp({
      email, options: { emailRedirectTo: `${location.origin}/auth/callback` },
    })
    setMsg(error ? error.message : 'Check your email for a sign-in link.')
  }
  return (
    <form onSubmit={send}>
      <h1>BigSky AI</h1>
      <p>Sign in with an emailed link. No password is stored.</p>
      <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" style={{ padding: 10, width: '100%', fontSize: 16 }} />
      <button style={{ marginTop: 12, padding: '10px 16px' }}>Send link</button>
      <p>{msg}</p>
    </form>
  )
}
