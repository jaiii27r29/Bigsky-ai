import { supabaseServer } from '@/lib/supabase/server'
// Stage 2 check page: proves login works and that row level security returns only your rows.
export default async function Home() {
  const sb = await supabaseServer()
  const { data: { user } } = await sb.auth.getUser()
  const { data: profile } = await sb.from('profiles').select('display_name,timezone,monitor_interval_minutes').single()
  const { count } = await sb.from('courses').select('*', { count: 'exact', head: true })
  return (
    <main>
      <h1>BigSky AI</h1>
      <p>Signed in as {user?.email}</p>
      <p>Timezone: {profile?.timezone} · Check every {profile?.monitor_interval_minutes} min · Courses stored: {count ?? 0}</p>
      <form action="/auth/signout" method="post"><button>Sign out</button></form>
    </main>
  )
}
