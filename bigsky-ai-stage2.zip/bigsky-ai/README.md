# BigSky AI (Stage 2: database and sign-in)

## Setup
1. Create a free project at supabase.com.
2. Database: follow **SETUP-SQL.md** (step-by-step SQL Editor instructions, with checks and fixes).
3. Authentication > URL Configuration: set Site URL to your deployed address (and add `http://localhost:3000/auth/callback` for local use).
4. Copy `.env.example` to `.env.local` and fill in the project URL and anon key (Project Settings > API).
5. `npm install && npm run dev`, open the site, request a sign-in link.
6. After your first login, turn OFF "Allow new users to sign up" (Authentication > Sign In / Providers) so only you can ever have an account.

## Deploy
Import the repo into Vercel, add the same environment variables, deploy. Never put the service role or Anthropic key in a NEXT_PUBLIC_ variable.

## Security notes
- Row Level Security is on for every table; each user only sees rows where user_id is their own id.
- The "files" storage bucket is private, with per-user folders.
- "submitted" status is blocked by the database unless submission_verified is true.
